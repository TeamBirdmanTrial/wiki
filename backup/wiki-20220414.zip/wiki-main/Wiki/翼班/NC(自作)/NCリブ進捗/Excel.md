Google drive にアップロードしてリンクを張ればアクセスできるようになる．

[NC翼進捗.xlsx](https://github.com/TeamBirdmanTrial/wiki/files/8453237/NC.xlsx)

テンプレート(これを編集しても反映されない)
