## 注意事項・禁止事項など
ここには人の安全や工具・製品などを守るために大切なことを見やすくまとめたいと思っています．

[電動工具の取扱い.pdf](https://github.com/TeamBirdmanTrial/wiki/files/8456169/02telecommunication5_tools_jp.pdf)  
[NC(自作)](NC(自作).md) 
