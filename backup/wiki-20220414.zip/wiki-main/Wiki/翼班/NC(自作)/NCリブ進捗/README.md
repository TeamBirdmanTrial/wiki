[スプレッドシート](https://docs.google.com/spreadsheets/d/1QgvS1YrmuJOplltXAACNwXdQtFNo46T1/edit#gid=518709190)
リブ単位の管理は多分Googleスプレッドシートとかのほうが管理しやすいと思う(配列みたいな表示が難しいため)
