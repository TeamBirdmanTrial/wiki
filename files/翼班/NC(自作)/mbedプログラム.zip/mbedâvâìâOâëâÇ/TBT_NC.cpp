#include "mbed.h"

/*
   This basic example just shows how to read the ADC internal channels raw values.
   Please look in the corresponding device reference manual for a complete
   description of how to make a temperature sensor, VBat or Vref measurement.
*/
int time_X;
int time_Y;
int time_Z;

float LOW_PW = 0.1;
int LOW_time = 1000;//ms

Ticker base;//100μs毎に動くプログラム

InterruptIn X_IN(D5);//ピンモード設定(割り込みピン)
InterruptIn Y_IN(D6);
InterruptIn Z_IN(D7);

PwmOut X_OUT(D2);//ピンモード設定(出力ピン)
PwmOut Y_OUT(D3);
PwmOut Z_OUT(D4);

void flip() {//1000μs毎に実行するプログラムの内容
    time_X = time_X++;
    time_Y = time_Y++;
    time_Z = time_Z++;
}



void reset_X() {
    time_X = 0;
}

void reset_Y() {
    time_Y = 0;
}

void reset_Z() {
    time_Z = 0;
}



int main() {
    X_OUT.period_us(200);//pwmの周波数5kHz
    Y_OUT.period_us(200);
    Z_OUT.period_us(200);
    
    X_IN.mode(PullUp);//ピンモード設定(プルアップ)
    Y_IN.mode(PullUp);
    Z_IN.mode(PullUp);
    
    X_IN.rise(&reset_X);//立ち上がり割り込み
    Y_IN.rise(&reset_Y);
    Z_IN.rise(&reset_Z);
    
    base.attach_us(&flip, 1000);//1000μs毎にbaseを実行
    
    
    while(1) {//常に実行
        if (time_X >= LOW_time){
            time_X = LOW_time;
            X_OUT = LOW_PW;
        }else{
            X_OUT = 1;
        }
        
        if (time_Y >= LOW_time){
            time_Y = LOW_time;
            Y_OUT = LOW_PW;
        }else{
            Y_OUT = 1;
        }
        
        if (time_Z >= LOW_time){
            time_Z = LOW_time;
            Z_OUT = LOW_PW;
        }else{
            Z_OUT = 1;
        }
    }
}