[NCの使い方翼(PC) .pdf](https://github.com/TeamBirdmanTrial/wiki/files/8453130/NC.PC.pdf)

大体これにかいてあります．(適当)


